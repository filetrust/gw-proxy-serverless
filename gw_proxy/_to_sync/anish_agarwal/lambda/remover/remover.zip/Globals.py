class Globals:
    aws_session_region_name  = 'eu-west-1'          #'eu-west-2'
    lambda_layers_s3_bucket  = 'gw-proxy-lambda-layers'     # must be unique in AWS