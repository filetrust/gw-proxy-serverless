
def run(event, context):
    from osbot_aws.Globals import Globals
    return 'checking aws api: {0}'.format(Globals)